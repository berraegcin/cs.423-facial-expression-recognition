"""SOTA benchmark for FER2013 — code-only counterpart of sota_benchmark.ipynb.

Runs DeepFace's built-in emotion CNN, plus VGG-Face and FaceNet as frozen
feature extractors with logistic-regression and linear-SVM heads, on the
FER2013 test split. Also merges teammate predictions (HOG+LBP+SVM, CNN) if
they are present in results/ as y_pred_<model>.npy files.

Usage:
    python sota_benchmark.py                # full test split (7,178 images)
    python sota_benchmark.py --subset 500   # smoke test on 500 images

Outputs (under results/):
    metrics_summary.csv        — one row per model
    per_class_<model>.csv      — per-class precision/recall/F1
    confusion_<model>.png      — normalized 7x7 confusion matrix (300 DPI)
    y_test.npy, y_pred_<model>.npy — arrays for downstream analysis
    fer2013_class_distribution.png, fer2013_samples.png, sota_comparison.png
"""

from __future__ import annotations

import argparse
import random
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.svm import LinearSVC

from src.data import DEEPFACE_TO_FER_INDEX, EMOTION_LABELS, load_fer2013
from src.embeddings import extract_embeddings, predict_emotions_builtin
from src.eval import append_summary, compute_metrics, save_results

RANDOM_STATE = 42
RESULTS_DIR = Path("results")


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument(
        "--subset",
        type=int,
        default=None,
        help="Eval on a random subset of N test images (default: full split).",
    )
    return p.parse_args()


def setup(subset: int | None) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    np.random.seed(RANDOM_STATE)
    random.seed(RANDOM_STATE)
    RESULTS_DIR.mkdir(exist_ok=True)

    summary_path = RESULTS_DIR / "metrics_summary.csv"
    if summary_path.exists():
        summary_path.unlink()
        print("Cleared old metrics_summary.csv")

    X_train, y_train, X_test, y_test = load_fer2013()
    print(f"Train: {X_train.shape}  Test: {X_test.shape}")
    print(f"Label order: {EMOTION_LABELS}")

    if subset is not None and subset < len(X_test):
        rng = np.random.default_rng(RANDOM_STATE)
        idx = rng.choice(len(X_test), size=subset, replace=False)
        X_eval, y_eval = X_test[idx], y_test[idx]
    else:
        X_eval, y_eval = X_test, y_test

    print(f"Evaluating on {len(X_eval)} images")
    np.save(RESULTS_DIR / "y_test.npy", y_eval)
    save_dataset_figures(X_train, y_train)
    return X_train, y_train, X_eval, y_eval, X_test, y_test


def save_dataset_figures(X_train: np.ndarray, y_train: np.ndarray) -> None:
    fig, ax = plt.subplots(figsize=(8, 4))
    counts = np.bincount(y_train, minlength=len(EMOTION_LABELS))
    sns.barplot(x=EMOTION_LABELS, y=counts, ax=ax)
    ax.set_ylabel("Train images")
    ax.set_title("FER2013 train-split class distribution")
    plt.tight_layout()
    fig.savefig(RESULTS_DIR / "fer2013_class_distribution.png", dpi=300, bbox_inches="tight")
    plt.close(fig)

    fig, axes = plt.subplots(1, 7, figsize=(14, 2.5))
    for i, name in enumerate(EMOTION_LABELS):
        idx = int(np.where(y_train == i)[0][0])
        axes[i].imshow(X_train[idx], cmap="gray")
        axes[i].set_title(name)
        axes[i].axis("off")
    plt.tight_layout()
    fig.savefig(RESULTS_DIR / "fer2013_samples.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def run_deepface_builtin(X_eval: np.ndarray, y_eval: np.ndarray) -> None:
    print("\n=== SOTA-A: DeepFace built-in emotion CNN ===")
    preds_str = predict_emotions_builtin(X_eval)
    y_pred = np.array([DEEPFACE_TO_FER_INDEX[p] for p in preds_str], dtype=np.int64)
    log_and_save("DeepFace-Emotion", y_eval, y_pred)


def run_backbone(
    backbone: str,
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_eval: np.ndarray,
    y_eval: np.ndarray,
    eval_split_name: str,
) -> tuple[np.ndarray, np.ndarray, StandardScaler]:
    print(f"\n=== Extracting {backbone} embeddings ===")
    train_emb = extract_embeddings(X_train, model_name=backbone, split_name="train")
    eval_emb = extract_embeddings(X_eval, model_name=backbone, split_name=eval_split_name)
    print(f"  train: {train_emb.shape}  eval: {eval_emb.shape}")

    scaler = StandardScaler().fit(train_emb)
    train_s = scaler.transform(train_emb)
    eval_s = scaler.transform(eval_emb)

    lr_name = "VGG-Face-LR" if backbone == "VGG-Face" else "FaceNet-LR"
    print(f"\n=== {lr_name}: logistic regression head ===")
    lr = LogisticRegression(
        max_iter=2000, class_weight="balanced", random_state=RANDOM_STATE, n_jobs=-1
    )
    lr.fit(train_s, y_train)
    log_and_save(lr_name, y_eval, lr.predict(eval_s))

    svm_name = "VGG-Face-SVM" if backbone == "VGG-Face" else "FaceNet-SVM"
    print(f"\n=== {svm_name}: linear-SVM head (ablation) ===")
    svm = LinearSVC(class_weight="balanced", random_state=RANDOM_STATE, max_iter=5000)
    svm.fit(train_s, y_train)
    log_and_save(svm_name, y_eval, svm.predict(eval_s))

    return train_emb, eval_emb, scaler


def log_and_save(model_name: str, y_eval: np.ndarray, y_pred: np.ndarray) -> None:
    metrics = compute_metrics(y_eval, y_pred, EMOTION_LABELS)
    print(
        f"  {model_name:<18}  acc={metrics['accuracy']:.4f}  "
        f"f1w={metrics['f1_weighted']:.4f}  f1m={metrics['f1_macro']:.4f}"
    )
    save_results(model_name, metrics, y_eval, y_pred, EMOTION_LABELS)
    append_summary(model_name, metrics)
    np.save(RESULTS_DIR / f"y_pred_{model_name}.npy", y_pred.astype(np.int64))


def merge_teammate_predictions(y_eval: np.ndarray) -> None:
    print("\n=== Merging teammate predictions (if present) ===")
    teammates = {
        "HOG+LBP+SVM": RESULTS_DIR / "y_pred_HOG+LBP+SVM.npy",
        "CNN": RESULTS_DIR / "y_pred_CNN.npy",
    }
    for model_name, path in teammates.items():
        if not path.exists():
            print(f"  [skip] {model_name}: {path.name} not found")
            continue
        y_pred = np.load(path)
        if y_pred.shape != y_eval.shape:
            print(
                f"  [skip] {model_name}: shape mismatch "
                f"({y_pred.shape} vs {y_eval.shape}). "
                "Re-run their pipeline on the full test split."
            )
            continue
        metrics = compute_metrics(y_eval, y_pred, EMOTION_LABELS)
        print(
            f"  {model_name:<18}  acc={metrics['accuracy']:.4f}  "
            f"f1w={metrics['f1_weighted']:.4f}  f1m={metrics['f1_macro']:.4f}"
        )
        save_results(model_name, metrics, y_eval, y_pred, EMOTION_LABELS)
        append_summary(model_name, metrics)


def write_comparison_figure() -> None:
    summary = pd.read_csv(RESULTS_DIR / "metrics_summary.csv").sort_values(
        "accuracy", ascending=False
    )
    print("\n=== Final comparison ===")
    print(summary.to_string(index=False))

    fig, ax = plt.subplots(figsize=(9, 4))
    long = summary.melt(
        id_vars="model",
        value_vars=["accuracy", "f1_weighted", "f1_macro"],
        var_name="metric",
        value_name="value",
    )
    sns.barplot(data=long, x="model", y="value", hue="metric", ax=ax)
    ax.set_ylim(0, 1)
    ax.set_title("Model comparison on FER2013")
    ax.set_xlabel("")
    plt.xticks(rotation=20, ha="right")
    plt.tight_layout()
    fig.savefig(RESULTS_DIR / "sota_comparison.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    args = parse_args()
    X_train, y_train, X_eval, y_eval, _, _ = setup(args.subset)
    eval_split_name = f"eval{len(X_eval)}"

    run_deepface_builtin(X_eval, y_eval)
    run_backbone("VGG-Face", X_train, y_train, X_eval, y_eval, eval_split_name)
    run_backbone("Facenet", X_train, y_train, X_eval, y_eval, eval_split_name)
    merge_teammate_predictions(y_eval)
    write_comparison_figure()
    print(f"\nDone. Outputs written to {RESULTS_DIR.resolve()}/")


if __name__ == "__main__":
    main()
