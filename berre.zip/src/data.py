"""FER2013 dataset loading utilities.

We load FER2013 from a local folder downloaded from Kaggle
(https://www.kaggle.com/datasets/msambare/fer2013). Place the unzipped
folders under ``data/fer2013/`` in the project root so that the layout is::

    data/fer2013/train/<class_name>/<img>.jpg
    data/fer2013/test/<class_name>/<img>.jpg

The seven class folders are named: angry, disgust, fear, happy, neutral, sad,
surprise. We map them to the canonical FER2013 index order in
``EMOTION_LABELS`` regardless of the alphabetic folder ordering on disk.

A HuggingFace mirror loader is also provided as a fallback if you happen to
find a working mirror; pass ``source="huggingface"`` to ``load_fer2013``.
"""

from __future__ import annotations

from pathlib import Path
from typing import Tuple

import numpy as np

EMOTION_LABELS = [
    "angry",
    "disgust",
    "fear",
    "happy",
    "neutral",
    "sad",
    "surprise",
]
_LABEL_TO_INDEX = {name: i for i, name in enumerate(EMOTION_LABELS)}

# DeepFace's analyze() returns lowercase emotion strings — same words as our
# labels, so the mapping is identity-by-name.
DEEPFACE_TO_FER_INDEX = dict(_LABEL_TO_INDEX)

_PROJECT_ROOT = Path(__file__).resolve().parent.parent
# Searched in order. The first directory containing both train/ and test/
# subfolders is used.
DEFAULT_DATA_CANDIDATES = [
    _PROJECT_ROOT / "data" / "fer2013",
    _PROJECT_ROOT / "archive",
    _PROJECT_ROOT / "fer2013",
    _PROJECT_ROOT / "data",
]


def _resolve_data_dir(explicit: Path | str | None) -> Path:
    if explicit is not None:
        p = Path(explicit)
        if (p / "train").is_dir() and (p / "test").is_dir():
            return p
        raise FileNotFoundError(
            f"data_dir={p} does not contain train/ and test/ subfolders."
        )
    for candidate in DEFAULT_DATA_CANDIDATES:
        if (candidate / "train").is_dir() and (candidate / "test").is_dir():
            return candidate
    raise FileNotFoundError(
        "Could not find FER2013 data. Searched: "
        + ", ".join(str(p) for p in DEFAULT_DATA_CANDIDATES)
        + ". Download from https://www.kaggle.com/datasets/msambare/fer2013 and "
        "unzip so that <root>/train/<class>/*.jpg exists."
    )


def load_fer2013(
    source: str = "local",
    data_dir: Path | str | None = None,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Return (X_train, y_train, X_test, y_test) as numpy arrays.

    X arrays: shape (N, 48, 48) dtype uint8 (grayscale).
    y arrays: shape (N,) dtype int64 with values in [0, 6] indexing
    EMOTION_LABELS.

    Parameters
    ----------
    source : "local" (default) | "huggingface"
        "local" reads the Kaggle msambare/fer2013 folder layout from
        ``data_dir``. "huggingface" attempts a small list of HF mirrors.
    data_dir : path
        Root that contains ``train/`` and ``test/`` subdirectories. Only
        used when source="local".
    """
    if source == "local":
        root = _resolve_data_dir(data_dir)
        print(f"Loading FER2013 from {root}")
        X_train, y_train = _read_split(root / "train")
        X_test, y_test = _read_split(root / "test")
        return X_train, y_train, X_test, y_test
    if source == "huggingface":
        return _load_from_huggingface()
    raise ValueError(f"Unknown source: {source!r}")


def _read_split(split_dir: Path) -> Tuple[np.ndarray, np.ndarray]:
    from PIL import Image

    images = []
    labels = []
    found_classes = sorted(p.name for p in split_dir.iterdir() if p.is_dir())
    missing = set(EMOTION_LABELS) - set(found_classes)
    if missing:
        raise FileNotFoundError(
            f"{split_dir} is missing class folders: {sorted(missing)}. "
            f"Found: {found_classes}"
        )

    for class_name in EMOTION_LABELS:
        class_idx = _LABEL_TO_INDEX[class_name]
        class_dir = split_dir / class_name
        for img_path in sorted(class_dir.iterdir()):
            if img_path.suffix.lower() not in {".jpg", ".jpeg", ".png"}:
                continue
            arr = np.asarray(Image.open(img_path).convert("L"), dtype=np.uint8)
            if arr.shape != (48, 48):
                # Some downloaders re-encode at different sizes; force 48x48.
                from PIL import Image as _Image

                arr = np.asarray(
                    _Image.fromarray(arr).resize((48, 48), _Image.BILINEAR),
                    dtype=np.uint8,
                )
            images.append(arr)
            labels.append(class_idx)

    if not images:
        raise RuntimeError(f"No images found under {split_dir}")
    return np.stack(images, axis=0), np.asarray(labels, dtype=np.int64)


def _load_from_huggingface() -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Best-effort HuggingFace fallback. Mirrors come and go — if all fail,
    use ``source='local'`` instead.
    """
    from datasets import load_dataset

    candidates = [
        "Jeneral/fer-2013",
        "nateraw/fer2013",
        "clip-benchmark/wds_fer2013",
    ]
    last_err: Exception | None = None
    ds = None
    for repo in candidates:
        try:
            ds = load_dataset(repo)
            break
        except Exception as e:
            last_err = e
            continue
    if ds is None:
        raise RuntimeError(
            f"All HF mirrors failed: {candidates}. Last error: {last_err}.\n"
            "Use source='local' after downloading from Kaggle."
        )

    train_split = ds["train"]
    test_split = ds.get("test", ds.get("validation"))
    if test_split is None:
        raise RuntimeError("No test/validation split in HF dataset")

    X_train, y_train = _hf_split_to_arrays(train_split)
    X_test, y_test = _hf_split_to_arrays(test_split)
    return X_train, y_train, X_test, y_test


def _hf_split_to_arrays(split) -> Tuple[np.ndarray, np.ndarray]:
    images = []
    labels = []
    for ex in split:
        img = ex["image"] if "image" in ex else ex["img"]
        arr = np.asarray(img.convert("L"), dtype=np.uint8)
        if arr.shape != (48, 48):
            from PIL import Image as _Image

            arr = np.asarray(
                _Image.fromarray(arr).resize((48, 48), _Image.BILINEAR), dtype=np.uint8
            )
        images.append(arr)
        labels.append(int(ex["label"]))
    return np.stack(images, axis=0), np.asarray(labels, dtype=np.int64)


def load_ckplus() -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Loader stub for the CK+ cross-dataset evaluation.

    Implement when ready. Expected return signature matches load_fer2013 so
    eval cells can be reused without modification.
    """
    raise NotImplementedError(
        "CK+ loader not implemented. See docstring for expected return signature."
    )
