"""Frozen feature extraction with DeepFace's VGG-Face and FaceNet backbones.

These backbones were pre-trained for face recognition / verification, not
emotion classification. We use them as fixed feature extractors and train a
linear head on FER2013 emotion labels in the notebook.

DeepFace's ``represent`` runs its own face detector by default. FER2013
images are 48x48 and already cropped to faces, so detection is skipped via
``enforce_detection=False, detector_backend='skip'``.
"""

from __future__ import annotations

import os
from pathlib import Path

import numpy as np
from tqdm import tqdm

CACHE_DIR = Path(__file__).resolve().parent.parent / "results" / "embeddings_cache"


def _to_rgb_224(img_gray: np.ndarray) -> np.ndarray:
    """Upscale 48x48 grayscale to 224x224 RGB.

    DeepFace internally resizes to each model's expected input, but feeding
    it a 3-channel uint8 array sidesteps PIL/cv2 mode mismatches.
    """
    import cv2

    rgb = cv2.cvtColor(img_gray, cv2.COLOR_GRAY2RGB)
    rgb = cv2.resize(rgb, (224, 224), interpolation=cv2.INTER_CUBIC)
    return rgb


def extract_embeddings(
    images: np.ndarray,
    model_name: str,
    split_name: str,
    use_cache: bool = True,
) -> np.ndarray:
    """Return (N, D) embedding matrix for the given images.

    Parameters
    ----------
    images : np.ndarray
        (N, 48, 48) uint8 grayscale FER2013 images.
    model_name : str
        DeepFace model name. Tested with "VGG-Face" and "Facenet".
    split_name : str
        Used only as a cache key (e.g., "train", "test").
    use_cache : bool
        If True and a cached .npy exists, load it instead of recomputing.
    """
    from deepface import DeepFace

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    cache_path = CACHE_DIR / f"{model_name.replace('/', '_')}_{split_name}.npy"
    if use_cache and cache_path.exists():
        return np.load(cache_path)

    embeddings = []
    for img in tqdm(images, desc=f"{model_name} [{split_name}]"):
        rgb = _to_rgb_224(img)
        rep = DeepFace.represent(
            img_path=rgb,
            model_name=model_name,
            enforce_detection=False,
            detector_backend="skip",
            align=False,
        )
        # DeepFace.represent returns a list of dicts (one per detected face);
        # with detector_backend='skip' there is exactly one entry.
        embeddings.append(np.asarray(rep[0]["embedding"], dtype=np.float32))

    arr = np.stack(embeddings, axis=0)
    np.save(cache_path, arr)
    return arr


def predict_emotions_builtin(images: np.ndarray) -> list[str]:
    """Run DeepFace's built-in emotion model on each image.

    Returns a list of predicted emotion strings (lowercase, matching
    ``EMOTION_LABELS`` from data.py).
    """
    from deepface import DeepFace

    preds = []
    for img in tqdm(images, desc="DeepFace emotion"):
        rgb = _to_rgb_224(img)
        result = DeepFace.analyze(
            img_path=rgb,
            actions=["emotion"],
            enforce_detection=False,
            detector_backend="skip",
            silent=True,
        )
        # analyze returns a list since v0.0.79+
        if isinstance(result, list):
            result = result[0]
        preds.append(result["dominant_emotion"])
    return preds
