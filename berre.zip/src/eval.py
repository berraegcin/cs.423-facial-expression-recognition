"""Evaluation helpers: metrics, confusion matrix, and result persistence."""

from __future__ import annotations

from pathlib import Path
from typing import Sequence

import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
)

RESULTS_DIR = Path(__file__).resolve().parent.parent / "results"


def compute_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    labels: Sequence[str],
) -> dict:
    """Return overall + per-class metrics in a single dict."""
    label_idx = list(range(len(labels)))
    report = classification_report(
        y_true,
        y_pred,
        labels=label_idx,
        target_names=labels,
        output_dict=True,
        zero_division=0,
    )
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "f1_weighted": f1_score(y_true, y_pred, average="weighted", zero_division=0),
        "f1_macro": f1_score(y_true, y_pred, average="macro", zero_division=0),
        "per_class": {
            name: {
                "precision": report[name]["precision"],
                "recall": report[name]["recall"],
                "f1": report[name]["f1-score"],
                "support": report[name]["support"],
            }
            for name in labels
        },
    }


def plot_confusion_matrix(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    labels: Sequence[str],
    save_path: Path | str,
    title: str,
) -> None:
    import matplotlib.pyplot as plt
    import seaborn as sns

    cm = confusion_matrix(y_true, y_pred, labels=list(range(len(labels))))
    cm_norm = cm.astype(np.float64) / cm.sum(axis=1, keepdims=True).clip(min=1)

    fig, ax = plt.subplots(figsize=(7, 6))
    sns.heatmap(
        cm_norm,
        annot=True,
        fmt=".2f",
        cmap="Blues",
        xticklabels=labels,
        yticklabels=labels,
        cbar=True,
        ax=ax,
    )
    ax.set_xlabel("Predicted")
    ax.set_ylabel("True")
    ax.set_title(title)
    plt.tight_layout()
    fig.savefig(save_path, dpi=300, bbox_inches="tight")
    plt.close(fig)


def save_results(
    model_name: str,
    metrics: dict,
    y_true: np.ndarray,
    y_pred: np.ndarray,
    labels: Sequence[str],
) -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    safe = model_name.replace("/", "_").replace(" ", "_")

    per_class_rows = [
        {"class": name, **vals} for name, vals in metrics["per_class"].items()
    ]
    pd.DataFrame(per_class_rows).to_csv(
        RESULTS_DIR / f"per_class_{safe}.csv", index=False
    )

    plot_confusion_matrix(
        y_true,
        y_pred,
        labels,
        save_path=RESULTS_DIR / f"confusion_{safe}.png",
        title=f"Confusion Matrix — {model_name}",
    )


def append_summary(model_name: str, metrics: dict) -> pd.DataFrame:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    summary_path = RESULTS_DIR / "metrics_summary.csv"
    row = {
        "model": model_name,
        "accuracy": metrics["accuracy"],
        "f1_weighted": metrics["f1_weighted"],
        "f1_macro": metrics["f1_macro"],
    }
    if summary_path.exists():
        df = pd.read_csv(summary_path)
        df = df[df["model"] != model_name]
        df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)
    else:
        df = pd.DataFrame([row])
    df.to_csv(summary_path, index=False)
    return df
